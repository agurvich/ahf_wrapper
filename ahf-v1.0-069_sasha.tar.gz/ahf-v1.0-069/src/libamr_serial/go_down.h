#include "../param.h"
#include "../tdef.h"

#ifndef GO_DOWN_INCLUDED
#define GO_DOWN_INCLUDED

gridls  *go_down          (gridls *cur_grid);

#endif

