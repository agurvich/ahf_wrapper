#include "../param.h"
#include "../tdef.h"

#ifndef REFINE_GRID_INCLUDED
#define REFINE_GRID_INCLUDED

boolean  refine_grid(gridls *new_grid, gridls *old_grid);

#endif

