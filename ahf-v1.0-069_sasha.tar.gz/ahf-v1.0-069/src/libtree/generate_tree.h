#include "../param.h"
#include "../tdef.h"

#ifndef GENERATE_TREE_H_INCLUDED
#define GENERATE_TREE_H_INCLUDED

void generate_tree(long unsigned npart, partptr fst_part, double Nth_dom);

#endif
