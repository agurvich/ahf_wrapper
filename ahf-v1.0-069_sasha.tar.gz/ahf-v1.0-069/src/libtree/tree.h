#include "../param.h"
#include "../tdef.h"

#ifndef TREE_INCLUDED
#define TREE_INCLUDED

#include "generate_tree.h"

#endif
