// Copyright (C) 2011, Steffen Knollmann
// Released under the terms of the GNU General Public License version 3.

#ifndef TIMER_H
#define TIMER_H


/*--- Includes ----------------------------------------------------------*/


/*--- Prototypes of exported functions ----------------------------------*/
extern double
timer_getTime(void);


#endif
