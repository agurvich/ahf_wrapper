#include "../common.h"
#include "../param.h"
#include "../tdef.h"

#ifndef TRUNC_ERR_INCLUDED
#define TRUNC_ERR_INCLUDED

double  trunc_err          (gridls *cur_grid);

#endif

