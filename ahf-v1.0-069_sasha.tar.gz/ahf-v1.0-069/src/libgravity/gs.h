#include "../common.h"
#include "../param.h"
#include "../tdef.h"

#ifndef GS_INCLUDED
#define GS_INCLUDED

void    gs                 (gridls *cur_grid);

#endif

