#include "../common.h"
#include "../param.h"
#include "../tdef.h"

#ifndef FFT_POTENTIAL_INCLUDED
#define FFT_POTENTIAL_INCLUDED

extern void fft_potential(flouble *array, long l1dim);

#endif

