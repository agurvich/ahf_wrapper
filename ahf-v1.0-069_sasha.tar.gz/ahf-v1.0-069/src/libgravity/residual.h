#include "../common.h"
#include "../param.h"
#include "../tdef.h"

#ifndef RESIDUAL_INCLUDED
#define RESIDUAL_INCLUDED

double  residual           (gridls *cur_grid);

#endif

